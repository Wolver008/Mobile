package com.mobile.controller;

import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mobile.bean.MobileBean;
import com.mobile.service.IMobileService;

@Controller
public class MobileController {
	@Autowired
	private IMobileService mserv;
	
	@RequestMapping("mobile")
	public ModelAndView viewAll(){
		ModelAndView mv=new ModelAndView();
		ArrayList<MobileBean> flist=mserv.getAllMobileInfo();
		mv.setViewName("mobile");
		mv.addObject("data", flist);
		return mv;
	}
	
	@RequestMapping("sucess")
		public String go()
		{
			return "sucess";
		}
		
	}
