package com.mobile.dao;

import java.util.ArrayList;

import com.mobile.bean.MobileBean;

public interface IMobileDao {

	public ArrayList<MobileBean> getAllMobileInfo();
}
