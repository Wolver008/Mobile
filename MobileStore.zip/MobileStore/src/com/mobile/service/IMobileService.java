package com.mobile.service;
import java.util.ArrayList;

import com.mobile.bean.MobileBean;

public interface IMobileService {

		public ArrayList<MobileBean> getAllMobileInfo();
	
	
}
