package com.mobile.service;

import java.util.ArrayList;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobile.bean.MobileBean;
import com.mobile.service.IMobileService;
import com.mobile.dao.IMobileDao;
@Service
public class MobileListImpl implements IMobileService {

	@Autowired
	private IMobileDao mdao;

	@Override
	public ArrayList<MobileBean> getAllMobileInfo() {
		
		return mdao.getAllMobileInfo();
	}
	
	}

