package com.mobile.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.NamedQuery;

@Entity
@NamedQuery(name="getAllMobileList",query="select m from MobileBean m")

public class MobileBean {


	@Id
	private Integer MobileId;
	private String MobileName;
	private String MobileType;
	private String MobileModel;
	private String MobilePrice;
	
	public MobileBean() 
	{
	}

	public MobileBean(Integer mobileId, String mobileName, String mobileType,
			String mobileModel, String mobilePrice) {
		super();
		MobileId = mobileId;
		MobileName = mobileName;
		MobileType = mobileType;
		MobileModel = mobileModel;
		MobilePrice = mobilePrice;
	}

	public Integer getMobileId() {
		return MobileId;
	}

	public void setMobileId(Integer mobileId) {
		MobileId = mobileId;
	}

	public String getMobileName() {
		return MobileName;
	}

	public void setMobileName(String mobileName) {
		MobileName = mobileName;
	}

	public String getMobileType() {
		return MobileType;
	}

	public void setMobileType(String mobileType) {
		MobileType = mobileType;
	}

	public String getMobileModel() {
		return MobileModel;
	}

	public void setMobileModel(String mobileModel) {
		MobileModel = mobileModel;
	}

	public String getMobilePrice() {
		return MobilePrice;
	}

	public void setMobilePrice(String mobilePrice) {
		MobilePrice = mobilePrice;
	}

	@Override
	public String toString() 
	{
		return this.MobileId+""+this.MobileName+""+this.MobileType+""+this.MobileModel+""+this.MobilePrice;
	}
	
	
	
}
